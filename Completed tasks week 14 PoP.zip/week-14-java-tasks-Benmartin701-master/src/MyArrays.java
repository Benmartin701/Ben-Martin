/** 
 * MyArrays class
 * This class contains all the array tasks following the week 13 lecture. 
 * 
 * @author melanie
 * @since 2019
 */
import java.util.*;
public class MyArrays {

	// Task 1
	public int addUpNumbers(int one,int two, int three, int four, int five) {
		int sum=one+two+three+four+five;
		return sum;
		
	}
	 
	//task 2
	
	public int addUpNumbers(int[]numbers) {
		int sum = 0;
		int i;
		for (i = 0; i < numbers.length; i++)
			{
				sum = sum + (numbers[i]);
			}
		return sum;
	}
	
	//task 3
	
	public double averageOfNumbers(int[]numbers) {
		double sum = 0;
		int i;
		for (i = 0; i < numbers.length; i++)
			{
				sum = sum + (numbers[i]);
			}
		double av = sum / i;
		return av;
	}
	 
	
	// Task 4
	public int[] convertToCelsius(int[]far) {
		int i;
		int[]cel= new int[5];
		for (i = 0; i < far.length; i++)
			{
				(cel[i]) = ((far[i]-32)*5)/9;
			}
		
	return cel;
	}
	
	//Task 5
	public String[] unitMarks(int[] testRes) {
		String[]formRes=new String[7];
		double tot=0;
		for(int i=0;i<testRes.length;i++) {
			tot=tot+testRes[i];
		}
		double av=tot/6;
		formRes[0]="APP:"+testRes[0];
		formRes[1]="BSAD:"+testRes[1];
		formRes[2]="CF:"+testRes[2];
		formRes[3]="DAD:"+testRes[3];
		formRes[4]="N&CS:"+testRes[4];
		formRes[5]="POP:"+testRes[5];
		formRes[6]="Average:"+av;
		return formRes;
	}
	
	
	//Task 6
	public String andTheWinnerIs(String[]potWinners) {
		Random num= new Random();
		int length =potWinners.length;
		int rannum=num.nextInt(length);
		return potWinners[rannum];
		
		
	}
	
}
