/** 
 * Salary class
 * This class contains all the Salary tasks following the week 13 lecture. 
 * 
 * @author Ben
 * @since 2019
 */


	
	public class Salary {

	// Task 1	
  	public int  salaryIncrease(int mySalary) {
  		mySalary= mySalary+200;
  		return mySalary;
	}
  	
	// Task 2

  		// Task 1	
  	  	public double  salaryIncrease(double mySalary) {
  	  		mySalary= mySalary+200.50;
  	  		return mySalary;
  		}
	
	
	// Task 3: 
	public double salaryIncrease(double mySalary, double percent) {
		percent= percent/100+1;
		mySalary= mySalary*percent;
		return mySalary;
	}
	
	
	// Task 4
	public double calculatePay(double mySalary) {
		double newSalary=mySalary-mySalary*0.15;
		newSalary=newSalary-mySalary*0.13;
		newSalary=newSalary/12;
		return newSalary;
	    
	}
	

	// Task 5 - this one is more of a challenge - you can come back to it later
	public String formatCurrency(double mySalary) {
		String format =java.text.NumberFormat.getCurrencyInstance().format(mySalary);
		return format;
		
	
	}	
	
}
