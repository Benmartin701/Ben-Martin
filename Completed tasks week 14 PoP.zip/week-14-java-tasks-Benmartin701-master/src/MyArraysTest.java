import java.util.Arrays ;
import java.util.*;
import java.util.*;
public class MyArraysTest {

	public static void main(String[] args) {
		MyArrays myArrays = new MyArrays();
		//task1 test
		System.out.println(myArrays.addUpNumbers(10,20,30,40,50));
		
		// task 2 test
		int[] numbers = {10,20,30,40,50};
		System.out.println(myArrays.addUpNumbers(numbers));
		
		//task 3 test
		System.out.println(myArrays.averageOfNumbers(numbers));
	
		//task 4 test
		int[]fahr= {70,65,84,90,45};
		
			System.out.println(Arrays.toString(myArrays.convertToCelsius(fahr)));
		
		

		//task 5 test
			int[]results1= {64,55,45,67,65,88};
			System.out.println(Arrays.toString(myArrays.unitMarks(results1)));
		
		
		//task 6 test
			String[]peeps= {"Ben","Gail","Jake","Noah","Robbie"};
			System.out.println(myArrays.andTheWinnerIs(peeps));
	}
}
