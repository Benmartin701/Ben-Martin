
/** 
 * Names class
 * This class contains all the String tasks following the week 13 lecture. 
 * 
 * @author melanie
 * @since 2019
 */

public class Names {
	
	// Task 1
	
	public String upperCaseName(String boris) {
		
		return boris.toUpperCase();
	}
	 
	
	// Task 2
	
	public String fullName(String firstName, String lastName) {
		
		String fullName=firstName +" "+ lastName;
		return fullName;
	}
	
	
	// Task 3
	
	public int letterCount(String name) {
		return name.length();
	}
	 
	
	// Task 4
	public boolean theSameName(String nameOne,String nameTwo) {
		boolean sameName = nameOne.equalsIgnoreCase(nameTwo);
		return sameName;
	}
	
	
	// Task 5
	public String properCaseName(String name) {
		String capitalName=name.toUpperCase();
		name=name.toLowerCase();
		char first=capitalName.charAt(0);
		
		name=name.replace(name.charAt(0),first);
		
	 return name;
	}
	 
}
