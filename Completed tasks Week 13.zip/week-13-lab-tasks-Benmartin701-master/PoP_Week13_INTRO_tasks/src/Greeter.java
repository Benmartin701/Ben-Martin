/** Week 12 Greeting task
 * 
 * @author melanie
 *
 */

public class Greeter {

	// Task 1
	public String sayHello(String name) {
		//what goes here?
		return name;
	}

// Task 2
	 public String sayAnything(String name2) {
		return name2;
	}
	
	
	// Task 3
	public String welcomeToUni(String Uni2, String Uni3, String Uni4) {
		return Uni2+","+Uni3 +","+Uni4; 
	}
	
	
	//Task 4
	public String aboutMe(String name, String address, String town, String qualifications, String job) {
		return name+ "\n" +address+ "\n" +town+"\n" +qualifications+"\n" +job;
	}
	
}
