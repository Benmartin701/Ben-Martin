
public class GreeterTest {

	public static void main(String[] args) {
		// Create an object so I can call the methods
		Greeter greeter = new Greeter();
		
		//Call each method in turn passing them the data,
		//write the data that comes back from the method to the console so you can see it
		
		System.out.println(greeter.sayHello("Melanie"));
		System.out.println(greeter.sayAnything("How are you"));
		System.out.println(greeter.welcomeToUni("Melanie Coles", "Bournemouth Uni", "First programming tasks"));
		System.out.println(greeter.aboutMe("Ben", "Bournemouth Uni","Gosport" , "Level 3 Btec D*D*D*", "security guard"));
	}

}
