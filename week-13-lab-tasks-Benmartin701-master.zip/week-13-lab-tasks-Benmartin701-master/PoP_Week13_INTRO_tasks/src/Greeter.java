/** Week 12 Greeting task
 * 
 * @author melanie
 *
 */

public class Greeter {

	// Task 1
	public String sayHello(String name) {
		//what goes here?
		return null;
	}

	/* Task 2
	 public ?? sayAnything(??) {
		return ??;
	}
	*/
	
	/* Task 3
	public ?? welcomeToUni(??) {
		return ??;
	}
	*/
	
	/* Task 4
	public ?? aboutMe(??) {
		return ??;
	}
	*/
}
