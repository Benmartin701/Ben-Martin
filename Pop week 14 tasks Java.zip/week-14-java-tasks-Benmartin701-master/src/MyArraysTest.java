

public class MyArraysTest {

	public static void main(String[] args) {
		MyArrays myArrays = new MyArrays();
		//task1 test
		System.out.println(myArrays.addUpNumbers(10,20,30,40,50));
		
		// task 2 test
		int[] numbers = {10,20,30,40,50};
		System.out.println(myArrays.addUpNumbers(numbers));
		
		//task 3 test
		System.out.println(myArrays.averageOfNumbers(numbers));
	
		//task 4 test
	

		//task 5 test
		
		
		//task 6 test
		
	}
}
