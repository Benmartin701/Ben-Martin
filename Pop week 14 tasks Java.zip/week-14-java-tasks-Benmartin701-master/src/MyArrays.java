/** 
 * MyArrays class
 * This class contains all the array tasks following the week 13 lecture. 
 * 
 * @author melanie
 * @since 2019
 */

public class MyArrays {

	// Task 1
	public int addUpNumbers(int one,int two, int three, int four, int five) {
		int sum=one+two+three+four+five;
		return sum;
		
	}
	 
	//task 2
	
	public int addUpNumbers(int[]numbers) {
		int sum = 0;
		int i;
		for (i = 0; i < numbers.length; i++)
			{
				sum = sum + (numbers[i]);
			}
		return sum;
	}
	
	//task 3
	
	public double averageOfNumbers(int[]numbers) {
		double sum = 0;
		int i;
		for (i = 0; i < numbers.length; i++)
			{
				sum = sum + (numbers[i]);
			}
		double av = sum / i;
		return av;
	}
	 
	
	/* Task 4
	public ?? convertToCelsius(??) {
		??
	}
	 */
	
	/*Task 5
	public ?? unitMarks(??) {
		??
	}
	*/
	
	/*Task 6
	public ?? andTheWinnerIs(??) {
		??
	}
	*/
}
